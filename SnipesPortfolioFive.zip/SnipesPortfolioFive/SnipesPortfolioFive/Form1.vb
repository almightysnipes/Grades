﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim Avg As Double
        Avg = TextBox1.Text
        Select Case Avg
            Case 90 To 100
                TextBox2.Text = "Congrats! You get an A!"
                PictureBox1.Visible = True
            Case 80 To 89.99
                TextBox2.Text = "Congrats! You get a B!"
                PictureBox1.Visible = True
            Case 70 To 79.99
                TextBox2.Text = "You get a C! Watch yourself!"
                PictureBox2.Visible = True
            Case 60 To 69.99
                TextBox2.Text = "Unfortunately, you have a D!"
                PictureBox3.Visible = True
            Case 0 To 50
                TextBox2.Text = "You have an F! Unacceptable!"
                PictureBox3.Visible = True
        End Select

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        PictureBox1.Visible = False
        PictureBox2.Visible = False
        PictureBox3.Visible = False
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()

    End Sub
End Class
